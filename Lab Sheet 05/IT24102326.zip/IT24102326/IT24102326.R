setwd("C:\\Users\\User\\Desktop\\SLIIT Y2S1\\PAS\\Lab Answers\\Lab_05\\IT24102326")
getwd()

delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)

head(Delivery_Times)


hist(Delivery_Times$Delivery_Time_.minutes.,main = "Histogram of Delivery Times.",breaks = seq(20,70,leagth=10),right = FALSE, xlab = "Delivery Times")

freq_table <- table(cut(Delivery_Times$Delivery_Time_.minutes.,breaks = seq(20,70,by=5), right = FALSE))
freq_table
cum_freq<-cumsum(freq_table)
mindpoints<-seq(20,65,by=5)+2.5
plot(mindpoints,cum_freq,type="o",lwd=2,
     xlab="Delivery Time minutes",
     ylab="Cumulative Frequency",
     main="Cumulative Frequency Polygon (ogive)")
grid()

